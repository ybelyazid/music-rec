


usage () {
  echo "usage: mltrain.sh  [gs://]job_and_data_dir [path_to/]<input_file>.csv

Use 'local' to train locally with a local data file, and 'train' and 'tune' to
run on ML Engine.  For ML Engine cloud jobs the data_dir must be prefixed with
gs:// and point to an existing bucket, and the input file must reside on GCS.



Examples:

# train locally with unoptimized hyperparams on included web views data set
./mltrain.sh local ../data recommendation_events.csv --data-type web_views

# train on ML Engine with optimized hyperparams
./mltrain.sh train gs://rec_serve  data/recommendation_events.csv --data-type web_views --use-optimized

# tune hyperparams on ML Engine:
./mltrain.sh tune gs://rec_serve  data/recommendation_events.csv --data-type web_views
"

}

date

TIME=`date +"%Y%m%d_%H%M%S"`

# change to your preferred region
REGION=us-central1

if [[ $# < 2 ]]; then
  usage
  exit 1
fi

# set job vars
TRAIN_JOB="train"
BUCKET="$1"
DATA_FILE="$2"
JOB_NAME=wals_ml_${TRAIN_JOB}_${TIME}


ARGS="--gcs-bucket $BUCKET --train-file ${DATA_FILE} --verbose-logging $@"

gcloud ai-platform jobs submit training ${JOB_NAME} \
  --region $REGION \
  --scale-tier=CUSTOM \
  --job-dir ${BUCKET}/jobs/${JOB_NAME} \
  --module-name trainer.task \
  --package-path trainer \
  --master-machine-type complex_model_m_gpu \
  --config trainer/config/config_train.json \
  --master-machine-type complex_model_m_gpu \
  --runtime-version 1.15 \
  -- \
  ${ARGS}



date
