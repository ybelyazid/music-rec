import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix

from util import get_nusers_nsongs

TEST_SET_RATIO = 10


def ratings_train_test(data_file_path, delimiter="\t"):
    """
    load the datset.
    Args:
        data file in txt or csv format
    Returns:
        array of user IDs for each row of the ratings matrix
        array of song IDs for each column of the rating matrix
        sparse coo_matrix for training
        sparse coo_matrix for test
    """
    headers = ["user_idx", "song_idx", "count"]
    header_row = None
    rating_df = pd.read_csv(data_file_path,
                            header=header_row,
                            names=headers,
                            sep=delimiter,
                            dtype={
                                'user_id': np.int32,
                                'song_id': np.int32,
                                'count': np.int32
                            })
    n_users, n_songs = get_nusers_nsongs()
    ratings = rating_df.values()
    train_sparse, test_sparse = create_sparse_train_and_test(ratings,
                                                             n_users, n_songs)

    return ratings[:, 0], ratings[:, 1], train_sparse, test_sparse


def create_sparse_train_and_test(ratings, n_users, n_items):
    test_set_size = len(ratings) / TEST_SET_RATIO
    test_set_idx = np.random.choice(range(len(ratings)),
                                    size=test_set_size, replace=False)
    test_set_idx = sorted(test_set_idx)

    ts_ratings = ratings[test_set_idx]
    tr_ratings = np.delete(ratings, test_set_idx, axis=0)

    u_tr, i_tr, r_tr = zip(*tr_ratings)
    tr_sparse = coo_matrix((r_tr, (u_tr, i_tr)), shape=(n_users, n_items))

    u_ts, i_ts, r_ts = zip(*ts_ratings)
    test_sparse = coo_matrix((r_ts, (u_ts, i_ts)), shape=(n_users, n_items))

    return tr_sparse, test_sparse
