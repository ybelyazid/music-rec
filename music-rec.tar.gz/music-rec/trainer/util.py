import os
import uuid

import sh

import tensorflow as tf
from tensorflow.core.framework.summary_pb2 import Summary

"""
def ensure_local_file(input_file):

  #Ensure the training ratings file is stored locally.
  
    if input_file.startswith('gs:/'):
        input_path = os.path.join('/tmp/', str(uuid.uuid4()))
        os.makedirs(input_path)
        tmp_input_file = os.path.join(input_path, os.path.basename(input_file))
        sh.gsutil("cp", "-r", input_file, tmp_input_file)
        return tmp_input_file
    else:
        return input_file
"""


def preprocess_data():
    songid_idx = {}
    with open("data/songid_index.txt", 'r') as f:
        for line in f:
            songid, songidx = line.strip().split(' ')
            songid_idx[songid] = int(songidx) - 1

    count_user = 0
    userid_idx = {}
    with open("data/users_id.txt", 'r') as f:
        for line in f:
            userid = line.strip()
            userid_idx[userid] = count_user
            count_user += 1

    with open('data/userid_songid_lcount.txt', 'r') as f_id:
        with open('data/useridx_songidx_lcount.txt', 'w') as f_idx:
            for line in f_id:
                userid, songid, lcount = line.strip().split('\t')
                user_idx = str(userid_idx[userid])
                song_idx = str(songid_idx[songid])
                lcount = str(lcount)
                f_idx.write(user_idx + '\t' + song_idx + '\t' +
                            lcount + '\n')


def get_nusers_nsongs():
    users = {}
    songs = {}
    with open('data/useridx_songidx_lcount.txt', 'r') as f_idx:
        for line in f_idx:
            user_idx, song_idx, lcount = line.strip().split('\t')
            users[user_idx] = 0
            songs[song_idx] = 0
    return len(users), len(songs)


if __name__ == '__main__':
    preprocess_data()
    # (110000, 163206)
    print(get_nusers_nsongs())
