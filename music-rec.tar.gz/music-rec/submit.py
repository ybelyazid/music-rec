"""

f = open('data/userid_songid_lcount.txt', 'r')
user_to_songs = {}
for line in f:
    user, song, _ = line.strip().split('\t')
    if user in user_to_songs:
        user_to_songs[user].append(song)
    else:
        user_to_songs[user] = [song]
f.close()
"""
#user_idx, song_idx, count





